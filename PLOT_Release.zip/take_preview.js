const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
  try {
    const browser = await puppeteer.launch({ headless: "new" });
    const page = await browser.newPage();
    // 16:9 modern laptop viewport
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    
    // Go to our local server
    await page.goto('http://localhost:3333', { waitUntil: 'networkidle0' });
    
    // Wait an extra second for fonts to render
    await new Promise(r => setTimeout(r, 1000));
    
    // Take a full beautiful screenshot
    await page.screenshot({ path: 'preview.png', fullPage: true });
    
    await browser.close();
    console.log("Screenshot saved to preview.png");
  } catch (err) {
    console.error(err);
  }
})();
